// stores/settings.js
import { defineStore } from 'pinia'
import { ref, watch } from 'vue'

export const useSettingsStore = defineStore('settings', () => {
  // Theme State
  const isDarkMode = ref(false)
  
  // Spalten-Konfiguration pro Tabelle
  const columnSettings = ref({
    analysis: {
      available: [
        { key: 'aId', label: 'ID', default: true },
        { key: 'sId', label: 'Sample ID', default: true },
        { key: 'sStamp', label: 'Timestamp', default: true },
        { key: 'pol', label: 'POL', default: true },
        { key: 'nat', label: 'NAT', default: false },
        { key: 'kal', label: 'KAL', default: false },
        { key: 'an', label: 'AN', default: false },
        { key: 'glu', label: 'GLU', default: false },
        { key: 'dry', label: 'DRY', default: false },
        { key: 'dateIn', label: 'Datum Ein', default: true },
        { key: 'dateOut', label: 'Datum Aus', default: false },
        { key: 'weightMea', label: 'Gewicht Mea', default: false },
        { key: 'weightNrm', label: 'Gewicht Nrm', default: false },
        { key: 'weightCur', label: 'Gewicht Cur', default: false },
        { key: 'aFlags', label: 'Flags', default: true },
        { key: 'lane', label: 'Lane', default: false },
        { key: 'comment', label: 'Kommentar', default: false }
      ],
      selected: []
    },
    sample: {
      available: [
        { key: 'sId', label: 'Sample ID', default: true },
        { key: 'sStamp', label: 'Timestamp', default: true },
        { key: 'name', label: 'Name', default: true },
        { key: 'weightNet', label: 'Gewicht Netto', default: true },
        { key: 'weightBru', label: 'Gewicht Brutto', default: false },
        { key: 'weightTar', label: 'Tara', default: false },
        { key: 'quantity', label: 'Menge', default: false },
        { key: 'distance', label: 'Distanz', default: false },
        { key: 'dateCrumbled', label: 'Datum Zerkleinert', default: false },
        { key: 'sFlags', label: 'Flags', default: true },
        { key: 'lane', label: 'Lane', default: false },
        { key: 'comment', label: 'Kommentar', default: false },
        { key: 'boxpos', label: 'Box Position', default: true }
      ],
      selected: []
    },
    box: {
      available: [
        { key: 'bId', label: 'Box ID', default: true },
        { key: 'name', label: 'Name', default: true },
        { key: 'numMax', label: 'Max. Positionen', default: true },
        { key: 'type', label: 'Typ', default: true },
        { key: 'comment', label: 'Kommentar', default: false }
      ],
      selected: []
    },
    boxpos: {
      available: [
        { key: 'bId', label: 'Box ID', default: true },
        { key: 'bposId', label: 'Position ID', default: true },
        { key: 'sId', label: 'Sample ID', default: true },
        { key: 'sStamp', label: 'Timestamp', default: true }
      ],
      selected: []
    },
    log: {
      available: [
        { key: 'logId', label: 'Log ID', default: true },
        { key: 'dateCreated', label: 'Erstellt', default: true },
        { key: 'level', label: 'Level', default: true },
        { key: 'info', label: 'Info', default: true },
        { key: 'sId', label: 'Sample ID', default: false },
        { key: 'aId', label: 'Analysis ID', default: false }
      ],
      selected: []
    }
  })

  // Initialisiere ausgewählte Spalten mit Defaults
  function initializeColumns() {
    Object.keys(columnSettings.value).forEach(table => {
      const tableConfig = columnSettings.value[table]
      if (tableConfig.selected.length === 0) {
        tableConfig.selected = tableConfig.available
          .filter(col => col.default)
          .map(col => col.key)
      }
    })
  }

  // Lade Settings aus LocalStorage
  function loadSettings() {
    try {
      // Theme laden
      const savedTheme = localStorage.getItem('venlab-theme')
      if (savedTheme) {
        isDarkMode.value = savedTheme === 'dark'
      } else {
        // System-Präferenz verwenden
        isDarkMode.value = window.matchMedia('(prefers-color-scheme: dark)').matches
      }

      // Spalten-Settings laden
      const savedColumns = localStorage.getItem('venlab-columns')
      if (savedColumns) {
        const parsed = JSON.parse(savedColumns)
        Object.keys(parsed).forEach(table => {
          if (columnSettings.value[table]) {
            columnSettings.value[table].selected = parsed[table]
          }
        })
      } else {
        initializeColumns()
      }
    } catch (e) {
      console.error('Fehler beim Laden der Settings:', e)
      initializeColumns()
    }
  }

  // Speichere Settings in LocalStorage
  function saveSettings() {
    try {
      localStorage.setItem('venlab-theme', isDarkMode.value ? 'dark' : 'light')
      
      const columnsToSave = {}
      Object.keys(columnSettings.value).forEach(table => {
        columnsToSave[table] = columnSettings.value[table].selected
      })
      localStorage.setItem('venlab-columns', JSON.stringify(columnsToSave))
    } catch (e) {
      console.error('Fehler beim Speichern der Settings:', e)
    }
  }

  // Toggle Theme
  function toggleTheme() {
    isDarkMode.value = !isDarkMode.value
    saveSettings()
  }

  // Spalten für Tabelle setzen
  function setColumns(table, columns) {
    if (columnSettings.value[table]) {
      columnSettings.value[table].selected = columns
      saveSettings()
    }
  }

  // Spalten für Tabelle abrufen
  function getColumns(table) {
    return columnSettings.value[table]?.selected || []
  }

  // Alle verfügbaren Spalten für Tabelle
  function getAvailableColumns(table) {
    return columnSettings.value[table]?.available || []
  }

  // Header für DataTable generieren
  function getTableHeaders(table) {
    const config = columnSettings.value[table]
    if (!config) return []
    
    return config.available
      .filter(col => config.selected.includes(col.key))
      .map(col => ({
        title: col.label,
        key: col.key,
        sortable: true
      }))
  }

  // Settings auf Standard zurücksetzen
  function resetToDefaults() {
    Object.keys(columnSettings.value).forEach(table => {
      const tableConfig = columnSettings.value[table]
      tableConfig.selected = tableConfig.available
        .filter(col => col.default)
        .map(col => col.key)
    })
    saveSettings()
  }

  // Auto-Save bei Änderungen
  watch(isDarkMode, saveSettings)

  // Initialisierung
  loadSettings()

  return {
    isDarkMode,
    columnSettings,
    toggleTheme,
    setColumns,
    getColumns,
    getAvailableColumns,
    getTableHeaders,
    resetToDefaults,
    loadSettings,
    saveSettings
  }
})
