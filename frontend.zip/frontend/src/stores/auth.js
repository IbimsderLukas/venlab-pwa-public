// stores/auth.js
import { defineStore } from 'pinia'
import { ref, computed } from 'vue'
import axios from 'axios'

export const useAuthStore = defineStore('auth', () => {
  // State
  const user = ref(null)
  const token = ref(null)
  const isLoading = ref(false)
  const error = ref(null)

  // Computed
  const isAuthenticated = computed(() => !!token.value)
  const username = computed(() => user.value?.username || '')
  const role = computed(() => user.value?.role || '')

  // API Base URL
  const API_URL = import.meta.env.VITE_API_URL || '/api'

  // Token aus LocalStorage laden
  function loadToken() {
    try {
      const savedToken = localStorage.getItem('venlab-token')
      const savedUser = localStorage.getItem('venlab-user')
      
      if (savedToken && savedUser) {
        token.value = savedToken
        user.value = JSON.parse(savedUser)
        
        // Axios Header setzen
        axios.defaults.headers.common['Authorization'] = `Bearer ${savedToken}`
        
        return true
      }
    } catch (e) {
      console.error('Fehler beim Laden des Tokens:', e)
      logout()
    }
    return false
  }

  // Login
  async function login(username, password) {
    isLoading.value = true
    error.value = null

    try {
      const response = await axios.post(`${API_URL}/auth/login`, {
        username,
        password
      })

      const { token: newToken, user: userData } = response.data

      // Speichern
      token.value = newToken
      user.value = userData

      // LocalStorage
      localStorage.setItem('venlab-token', newToken)
      localStorage.setItem('venlab-user', JSON.stringify(userData))

      // Axios Header setzen
      axios.defaults.headers.common['Authorization'] = `Bearer ${newToken}`

      return true
    } catch (e) {
      console.error('Login fehlgeschlagen:', e)
      error.value = e.response?.data?.message || 'Login fehlgeschlagen'
      return false
    } finally {
      isLoading.value = false
    }
  }

  // Logout
  function logout() {
    token.value = null
    user.value = null
    error.value = null

    localStorage.removeItem('venlab-token')
    localStorage.removeItem('venlab-user')

    delete axios.defaults.headers.common['Authorization']
  }

  // Token validieren
  async function validateToken() {
    if (!token.value) return false

    try {
      const response = await axios.get(`${API_URL}/auth/validate`)
      return response.status === 200
    } catch (e) {
      console.error('Token ungültig:', e)
      logout()
      return false
    }
  }

  // Registrierung (falls benötigt)
  async function register(userData) {
    isLoading.value = true
    error.value = null

    try {
      const response = await axios.post(`${API_URL}/auth/register`, userData)
      return response.data
    } catch (e) {
      console.error('Registrierung fehlgeschlagen:', e)
      error.value = e.response?.data?.message || 'Registrierung fehlgeschlagen'
      throw e
    } finally {
      isLoading.value = false
    }
  }

  // Initialisierung
  loadToken()

  return {
    user,
    token,
    isLoading,
    error,
    isAuthenticated,
    username,
    role,
    login,
    logout,
    loadToken,
    validateToken,
    register
  }
})
