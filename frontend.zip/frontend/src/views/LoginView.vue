<template>
  <v-container class="fill-height" fluid>
    <v-row align="center" justify="center">
      <v-col cols="12" sm="8" md="4">
        <v-card class="elevation-12">
          <v-toolbar color="primary" dark flat>
            <v-toolbar-title>VenLab - Login</v-toolbar-title>
            <v-spacer />
            <ThemeSwitch />
          </v-toolbar>

          <v-card-text>
            <v-form ref="form" v-model="valid" @submit.prevent="handleLogin">
              <v-text-field
                v-model="username"
                label="Benutzername"
                prepend-icon="mdi-account"
                :rules="[rules.required]"
                :disabled="authStore.isLoading"
                autocomplete="username"
              />

              <v-text-field
                v-model="password"
                label="Passwort"
                prepend-icon="mdi-lock"
                :type="showPassword ? 'text' : 'password'"
                :append-icon="showPassword ? 'mdi-eye' : 'mdi-eye-off'"
                @click:append="showPassword = !showPassword"
                :rules="[rules.required]"
                :disabled="authStore.isLoading"
                autocomplete="current-password"
              />

              <v-alert
                v-if="authStore.error"
                type="error"
                density="compact"
                class="mb-4"
              >
                {{ authStore.error }}
              </v-alert>

              <v-btn
                type="submit"
                color="primary"
                block
                size="large"
                :loading="authStore.isLoading"
                :disabled="!valid"
              >
                Anmelden
              </v-btn>
            </v-form>
          </v-card-text>

          <v-card-actions class="justify-center pb-4">
            <span class="text-caption text-grey">
              VenLab PWA v1.0.0
            </span>
          </v-card-actions>
        </v-card>

        <!-- PWA Install Prompt -->
        <v-card v-if="showInstallPrompt" class="mt-4">
          <v-card-text class="d-flex align-center">
            <v-icon color="primary" class="mr-3">mdi-cellphone-arrow-down</v-icon>
            <div class="flex-grow-1">
              <div class="text-body-2">App installieren</div>
              <div class="text-caption text-grey">Für schnelleren Zugriff</div>
            </div>
            <v-btn
              color="primary"
              variant="tonal"
              size="small"
              @click="installPWA"
            >
              Installieren
            </v-btn>
          </v-card-text>
        </v-card>
      </v-col>
    </v-row>
  </v-container>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { useAuthStore } from '@/stores/auth'
import ThemeSwitch from '@/components/ThemeSwitch.vue'

const router = useRouter()
const authStore = useAuthStore()

const form = ref(null)
const valid = ref(false)
const username = ref('')
const password = ref('')
const showPassword = ref(false)

const rules = {
  required: v => !!v || 'Dieses Feld ist erforderlich'
}

// PWA Install
const showInstallPrompt = ref(false)
let deferredPrompt = null

onMounted(() => {
  // Check if already logged in
  if (authStore.isAuthenticated) {
    router.push('/')
  }

  // PWA Install Prompt
  window.addEventListener('beforeinstallprompt', (e) => {
    e.preventDefault()
    deferredPrompt = e
    showInstallPrompt.value = true
  })
})

async function handleLogin() {
  if (!valid.value) return

  const success = await authStore.login(username.value, password.value)
  
  if (success) {
    router.push('/')
  }
}

async function installPWA() {
  if (!deferredPrompt) return

  deferredPrompt.prompt()
  const { outcome } = await deferredPrompt.userChoice
  
  if (outcome === 'accepted') {
    showInstallPrompt.value = false
  }
  deferredPrompt = null
}
</script>

<style scoped>
.fill-height {
  min-height: 100vh;
}
</style>
