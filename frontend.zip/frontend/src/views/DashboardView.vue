<template>
  <v-container fluid>
    <v-row>
      <v-col cols="12">
        <h1 class="text-h4 mb-4">
          <v-icon class="mr-2">mdi-view-dashboard</v-icon>
          Dashboard
        </h1>
      </v-col>
    </v-row>

    <!-- Stats Cards -->
    <v-row>
      <v-col cols="12" sm="6" md="3">
        <v-card class="card-hover">
          <v-card-text class="d-flex align-center">
            <v-avatar color="primary" size="56" class="mr-4">
              <v-icon size="32">mdi-chart-bar</v-icon>
            </v-avatar>
            <div>
              <div class="text-h4">{{ stats.analyses }}</div>
              <div class="text-caption text-grey">Analysen</div>
            </div>
          </v-card-text>
        </v-card>
      </v-col>

      <v-col cols="12" sm="6" md="3">
        <v-card class="card-hover">
          <v-card-text class="d-flex align-center">
            <v-avatar color="success" size="56" class="mr-4">
              <v-icon size="32">mdi-test-tube</v-icon>
            </v-avatar>
            <div>
              <div class="text-h4">{{ stats.samples }}</div>
              <div class="text-caption text-grey">Samples</div>
            </div>
          </v-card-text>
        </v-card>
      </v-col>

      <v-col cols="12" sm="6" md="3">
        <v-card class="card-hover">
          <v-card-text class="d-flex align-center">
            <v-avatar color="info" size="56" class="mr-4">
              <v-icon size="32">mdi-package-variant</v-icon>
            </v-avatar>
            <div>
              <div class="text-h4">{{ stats.boxes }}</div>
              <div class="text-caption text-grey">Boxen</div>
            </div>
          </v-card-text>
        </v-card>
      </v-col>

      <v-col cols="12" sm="6" md="3">
        <v-card class="card-hover">
          <v-card-text class="d-flex align-center">
            <v-avatar color="warning" size="56" class="mr-4">
              <v-icon size="32">mdi-file-document</v-icon>
            </v-avatar>
            <div>
              <div class="text-h4">{{ stats.logs }}</div>
              <div class="text-caption text-grey">Log Einträge</div>
            </div>
          </v-card-text>
        </v-card>
      </v-col>
    </v-row>

    <!-- Quick Actions -->
    <v-row class="mt-4">
      <v-col cols="12" md="6">
        <v-card>
          <v-card-title>
            <v-icon class="mr-2">mdi-lightning-bolt</v-icon>
            Schnellzugriff
          </v-card-title>
          <v-card-text>
            <v-row>
              <v-col cols="6">
                <v-btn
                  block
                  color="primary"
                  variant="tonal"
                  prepend-icon="mdi-chart-bar"
                  to="/analysis"
                >
                  Analysen
                </v-btn>
              </v-col>
              <v-col cols="6">
                <v-btn
                  block
                  color="success"
                  variant="tonal"
                  prepend-icon="mdi-test-tube"
                  to="/sample"
                >
                  Samples
                </v-btn>
              </v-col>
              <v-col cols="6">
                <v-btn
                  block
                  color="info"
                  variant="tonal"
                  prepend-icon="mdi-package-variant"
                  to="/box"
                >
                  Boxen
                </v-btn>
              </v-col>
              <v-col cols="6">
                <v-btn
                  block
                  color="warning"
                  variant="tonal"
                  prepend-icon="mdi-file-document"
                  to="/log"
                >
                  Logs
                </v-btn>
              </v-col>
            </v-row>
          </v-card-text>
        </v-card>
      </v-col>

      <!-- System Info -->
      <v-col cols="12" md="6">
        <v-card>
          <v-card-title>
            <v-icon class="mr-2">mdi-information</v-icon>
            System Info
          </v-card-title>
          <v-card-text>
            <v-list density="compact">
              <v-list-item>
                <template v-slot:prepend>
                  <v-icon>mdi-account</v-icon>
                </template>
                <v-list-item-title>Angemeldet als</v-list-item-title>
                <v-list-item-subtitle>{{ authStore.username }}</v-list-item-subtitle>
              </v-list-item>
              
              <v-list-item>
                <template v-slot:prepend>
                  <v-icon>mdi-shield-account</v-icon>
                </template>
                <v-list-item-title>Rolle</v-list-item-title>
                <v-list-item-subtitle>{{ authStore.role }}</v-list-item-subtitle>
              </v-list-item>

              <v-list-item>
                <template v-slot:prepend>
                  <v-icon>mdi-cellphone</v-icon>
                </template>
                <v-list-item-title>PWA Status</v-list-item-title>
                <v-list-item-subtitle>
                  {{ isPWA ? 'Installiert' : 'Browser-Modus' }}
                </v-list-item-subtitle>
              </v-list-item>

              <v-list-item>
                <template v-slot:prepend>
                  <v-icon>mdi-theme-light-dark</v-icon>
                </template>
                <v-list-item-title>Theme</v-list-item-title>
                <v-list-item-subtitle>
                  {{ settingsStore.isDarkMode ? 'Dunkel' : 'Hell' }}
                </v-list-item-subtitle>
              </v-list-item>
            </v-list>
          </v-card-text>
        </v-card>
      </v-col>
    </v-row>
  </v-container>
</template>

<script setup>
import { ref, onMounted, computed } from 'vue'
import { useAuthStore } from '@/stores/auth'
import { useSettingsStore } from '@/stores/settings'
import axios from 'axios'

const authStore = useAuthStore()
const settingsStore = useSettingsStore()

const stats = ref({
  analyses: 0,
  samples: 0,
  boxes: 0,
  logs: 0
})

const isPWA = computed(() => 
  window.matchMedia('(display-mode: standalone)').matches
)

async function loadStats() {
  try {
    const [analyses, samples, boxes] = await Promise.all([
      axios.get('/api/analysis').catch(() => ({ data: [] })),
      axios.get('/api/sample').catch(() => ({ data: [] })),
      axios.get('/api/box').catch(() => ({ data: [] }))
    ])

    stats.value.analyses = analyses.data?.length || 0
    stats.value.samples = samples.data?.length || 0
    stats.value.boxes = boxes.data?.length || 0
    stats.value.logs = '-' // Log count might be large
  } catch (e) {
    console.error('Stats laden fehlgeschlagen:', e)
  }
}

onMounted(() => {
  loadStats()
})
</script>
