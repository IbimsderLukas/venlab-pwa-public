<template>
  <v-container fluid>
    <v-row>
      <v-col cols="12">
        <v-card>
          <v-card-title class="d-flex align-center">
            <v-icon class="mr-2">mdi-chart-bar</v-icon>
            Analysen

            <v-spacer />

            <!-- Column Selector -->
            <ColumnSelector 
              table="analysis" 
              @update:columns="onColumnsChange"
              class="mr-2"
            />

            <!-- Refresh -->
            <v-btn
              icon
              variant="text"
              @click="loadData"
              :loading="loading"
            >
              <v-icon>mdi-refresh</v-icon>
            </v-btn>
          </v-card-title>

          <v-card-text>
            <!-- Search -->
            <v-text-field
              v-model="search"
              prepend-inner-icon="mdi-magnify"
              label="Suchen..."
              single-line
              hide-details
              clearable
              class="mb-4"
            />

            <!-- Data Table -->
            <v-data-table
              :headers="tableHeaders"
              :items="items"
              :search="search"
              :loading="loading"
              :items-per-page="10"
              class="elevation-0"
            >
              <!-- Date formatting -->
              <template v-slot:item.dateIn="{ item }">
                {{ formatDate(item.dateIn) }}
              </template>
              <template v-slot:item.dateOut="{ item }">
                {{ formatDate(item.dateOut) }}
              </template>
              <template v-slot:item.sStamp="{ item }">
                {{ formatDate(item.sStamp) }}
              </template>

              <!-- Flags with color -->
              <template v-slot:item.aFlags="{ item }">
                <v-chip 
                  :color="getFlagColor(item.aFlags)" 
                  size="small"
                  label
                >
                  {{ item.aFlags }}
                </v-chip>
              </template>

              <!-- Actions -->
              <template v-slot:item.actions="{ item }">
                <v-btn
                  icon
                  size="small"
                  variant="text"
                  @click="viewItem(item)"
                >
                  <v-icon>mdi-eye</v-icon>
                </v-btn>
                <v-btn
                  icon
                  size="small"
                  variant="text"
                  @click="editItem(item)"
                >
                  <v-icon>mdi-pencil</v-icon>
                </v-btn>
                <v-btn
                  icon
                  size="small"
                  variant="text"
                  color="error"
                  @click="deleteItem(item)"
                >
                  <v-icon>mdi-delete</v-icon>
                </v-btn>
              </template>

              <!-- No data -->
              <template v-slot:no-data>
                <v-alert type="info" class="ma-4">
                  Keine Daten vorhanden
                </v-alert>
              </template>
            </v-data-table>
          </v-card-text>
        </v-card>
      </v-col>
    </v-row>

    <!-- Edit/View Dialog -->
    <v-dialog v-model="dialog" max-width="600">
      <v-card>
        <v-card-title>
          {{ dialogMode === 'view' ? 'Details' : 'Bearbeiten' }}
        </v-card-title>
        <v-card-text>
          <v-form ref="form">
            <v-text-field
              v-model="editedItem.aId"
              label="ID"
              disabled
            />
            <v-text-field
              v-model="editedItem.sId"
              label="Sample ID"
              :disabled="dialogMode === 'view'"
            />
            <v-text-field
              v-model="editedItem.pol"
              label="POL"
              type="number"
              :disabled="dialogMode === 'view'"
            />
            <v-text-field
              v-model="editedItem.aFlags"
              label="Flags"
              :disabled="dialogMode === 'view'"
            />
          </v-form>
        </v-card-text>
        <v-card-actions>
          <v-spacer />
          <v-btn @click="dialog = false">Abbrechen</v-btn>
          <v-btn 
            v-if="dialogMode !== 'view'"
            color="primary" 
            @click="saveItem"
          >
            Speichern
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>

    <!-- Delete Dialog -->
    <v-dialog v-model="deleteDialog" max-width="400">
      <v-card>
        <v-card-title>Löschen bestätigen</v-card-title>
        <v-card-text>
          Möchten Sie diesen Eintrag wirklich löschen?
        </v-card-text>
        <v-card-actions>
          <v-spacer />
          <v-btn @click="deleteDialog = false">Abbrechen</v-btn>
          <v-btn color="error" @click="confirmDelete">Löschen</v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
  </v-container>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { useSettingsStore } from '@/stores/settings'
import ColumnSelector from '@/components/ColumnSelector.vue'
import axios from 'axios'

const settingsStore = useSettingsStore()

// State
const items = ref([])
const loading = ref(false)
const search = ref('')
const dialog = ref(false)
const deleteDialog = ref(false)
const dialogMode = ref('view')
const editedItem = ref({})
const itemToDelete = ref(null)

// Dynamic headers based on selected columns
const tableHeaders = computed(() => {
  const headers = settingsStore.getTableHeaders('analysis')
  // Add actions column
  headers.push({
    title: 'Aktionen',
    key: 'actions',
    sortable: false,
    width: '120px'
  })
  return headers
})

// Methods
function onColumnsChange() {
  // Headers werden automatisch durch computed aktualisiert
}

async function loadData() {
  loading.value = true
  try {
    const response = await axios.get('/api/analysis')
    items.value = response.data
  } catch (e) {
    console.error('Laden fehlgeschlagen:', e)
  } finally {
    loading.value = false
  }
}

function formatDate(date) {
  if (!date) return '-'
  return new Date(date).toLocaleString('de-AT')
}

function getFlagColor(flags) {
  if (!flags) return 'grey'
  if (flags.startsWith('F')) return 'success'
  if (flags.startsWith('V')) return 'warning'
  return 'grey'
}

function viewItem(item) {
  editedItem.value = { ...item }
  dialogMode.value = 'view'
  dialog.value = true
}

function editItem(item) {
  editedItem.value = { ...item }
  dialogMode.value = 'edit'
  dialog.value = true
}

function deleteItem(item) {
  itemToDelete.value = item
  deleteDialog.value = true
}

async function saveItem() {
  try {
    await axios.put(`/api/analysis/${editedItem.value.aId}`, editedItem.value)
    dialog.value = false
    loadData()
  } catch (e) {
    console.error('Speichern fehlgeschlagen:', e)
  }
}

async function confirmDelete() {
  try {
    await axios.delete(`/api/analysis/${itemToDelete.value.aId}`)
    deleteDialog.value = false
    loadData()
  } catch (e) {
    console.error('Löschen fehlgeschlagen:', e)
  }
}

onMounted(() => {
  loadData()
})
</script>
