<template>
  <v-container fluid>
    <v-card>
      <v-card-title class="d-flex align-center">
        <v-icon class="mr-2">mdi-package-variant</v-icon>
        Boxen
        <v-spacer />
        <ColumnSelector table="box" class="mr-2" />
        <v-btn icon variant="text" @click="loadData" :loading="loading">
          <v-icon>mdi-refresh</v-icon>
        </v-btn>
      </v-card-title>
      <v-card-text>
        <v-text-field
          v-model="search"
          prepend-inner-icon="mdi-magnify"
          label="Suchen..."
          single-line
          hide-details
          clearable
          class="mb-4"
        />
        <v-data-table
          :headers="tableHeaders"
          :items="items"
          :search="search"
          :loading="loading"
          :items-per-page="10"
        >
          <template v-slot:item.type="{ item }">
            <v-chip size="small">Typ {{ item.type }}</v-chip>
          </template>
          <template v-slot:item.actions="{ item }">
            <v-btn icon size="small" variant="text" @click="viewItem(item)">
              <v-icon>mdi-eye</v-icon>
            </v-btn>
            <v-btn icon size="small" variant="text" @click="editItem(item)">
              <v-icon>mdi-pencil</v-icon>
            </v-btn>
            <v-btn icon size="small" variant="text" color="error" @click="deleteItem(item)">
              <v-icon>mdi-delete</v-icon>
            </v-btn>
          </template>
        </v-data-table>
      </v-card-text>
    </v-card>
  </v-container>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { useSettingsStore } from '@/stores/settings'
import ColumnSelector from '@/components/ColumnSelector.vue'
import axios from 'axios'

const settingsStore = useSettingsStore()
const items = ref([])
const loading = ref(false)
const search = ref('')

const tableHeaders = computed(() => {
  const headers = settingsStore.getTableHeaders('box')
  headers.push({ title: 'Aktionen', key: 'actions', sortable: false, width: '120px' })
  return headers
})

async function loadData() {
  loading.value = true
  try {
    const response = await axios.get('/api/box')
    items.value = response.data
  } catch (e) {
    console.error('Laden fehlgeschlagen:', e)
  } finally {
    loading.value = false
  }
}

function viewItem(item) { console.log('View:', item) }
function editItem(item) { console.log('Edit:', item) }
function deleteItem(item) { console.log('Delete:', item) }

onMounted(() => loadData())
</script>
