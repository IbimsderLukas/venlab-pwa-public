<template>
  <v-container fluid>
    <v-card>
      <v-card-title class="d-flex align-center">
        <v-icon class="mr-2">mdi-file-document</v-icon>
        Log
        <v-chip class="ml-2" size="small" color="info">Nur Lesezugriff</v-chip>
        <v-spacer />
        <ColumnSelector table="log" class="mr-2" />
        <v-btn icon variant="text" @click="loadData" :loading="loading">
          <v-icon>mdi-refresh</v-icon>
        </v-btn>
      </v-card-title>
      <v-card-text>
        <v-row class="mb-4">
          <v-col cols="12" md="6">
            <v-text-field
              v-model="search"
              prepend-inner-icon="mdi-magnify"
              label="Suchen..."
              single-line
              hide-details
              clearable
            />
          </v-col>
          <v-col cols="12" md="6">
            <v-select
              v-model="levelFilter"
              :items="['Alle', 'DEBUG', 'INFO', 'WARN', 'ERROR', 'FATAL']"
              label="Log Level"
              hide-details
              clearable
            />
          </v-col>
        </v-row>
        
        <v-data-table
          :headers="tableHeaders"
          :items="filteredItems"
          :search="search"
          :loading="loading"
          :items-per-page="20"
        >
          <template v-slot:item.dateCreated="{ item }">
            {{ formatDate(item.dateCreated) }}
          </template>
          <template v-slot:item.level="{ item }">
            <v-chip :color="getLevelColor(item.level)" size="small" label>
              {{ item.level }}
            </v-chip>
          </template>
        </v-data-table>
      </v-card-text>
    </v-card>
  </v-container>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { useSettingsStore } from '@/stores/settings'
import ColumnSelector from '@/components/ColumnSelector.vue'
import axios from 'axios'

const settingsStore = useSettingsStore()
const items = ref([])
const loading = ref(false)
const search = ref('')
const levelFilter = ref('Alle')

const tableHeaders = computed(() => settingsStore.getTableHeaders('log'))

const filteredItems = computed(() => {
  if (!levelFilter.value || levelFilter.value === 'Alle') return items.value
  return items.value.filter(item => item.level === levelFilter.value)
})

async function loadData() {
  loading.value = true
  try {
    const response = await axios.get('/api/log')
    items.value = response.data
  } catch (e) {
    console.error('Laden fehlgeschlagen:', e)
  } finally {
    loading.value = false
  }
}

function formatDate(date) {
  return date ? new Date(date).toLocaleString('de-AT') : '-'
}

function getLevelColor(level) {
  const colors = {
    'DEBUG': 'grey',
    'INFO': 'blue',
    'WARN': 'orange',
    'ERROR': 'red',
    'FATAL': 'purple'
  }
  return colors[level] || 'grey'
}

onMounted(() => loadData())
</script>
