<template>
  <v-app :theme="currentTheme">
    <!-- Navigation Drawer -->
    <v-navigation-drawer
      v-if="authStore.isAuthenticated"
      v-model="drawer"
      app
    >
      <v-list-item
        :title="authStore.username"
        :subtitle="authStore.role"
        prepend-icon="mdi-account-circle"
      />

      <v-divider />

      <v-list density="compact" nav>
        <v-list-item
          v-for="item in menuItems"
          :key="item.path"
          :to="item.path"
          :prepend-icon="item.icon"
          :title="item.title"
        />
      </v-list>

      <template v-slot:append>
        <div class="pa-2">
          <v-btn
            block
            color="error"
            variant="tonal"
            prepend-icon="mdi-logout"
            @click="handleLogout"
          >
            Abmelden
          </v-btn>
        </div>
      </template>
    </v-navigation-drawer>

    <!-- App Bar -->
    <v-app-bar v-if="authStore.isAuthenticated" app>
      <v-app-bar-nav-icon @click="drawer = !drawer" />
      
      <v-app-bar-title>
        <v-icon class="mr-2">mdi-flask</v-icon>
        VenLab
      </v-app-bar-title>

      <v-spacer />

      <!-- API Status -->
      <v-chip
        :color="apiStatus ? 'success' : 'error'"
        size="small"
        class="mr-2"
      >
        <v-icon start size="small">
          {{ apiStatus ? 'mdi-check-circle' : 'mdi-alert-circle' }}
        </v-icon>
        {{ apiStatus ? 'Online' : 'Offline' }}
      </v-chip>

      <!-- Theme Switch -->
      <ThemeSwitch />

      <!-- User Menu -->
      <v-menu>
        <template v-slot:activator="{ props }">
          <v-btn icon v-bind="props">
            <v-icon>mdi-account-circle</v-icon>
          </v-btn>
        </template>
        <v-list>
          <v-list-item>
            <v-list-item-title>{{ authStore.username }}</v-list-item-title>
            <v-list-item-subtitle>{{ authStore.role }}</v-list-item-subtitle>
          </v-list-item>
          <v-divider />
          <v-list-item @click="handleLogout">
            <template v-slot:prepend>
              <v-icon>mdi-logout</v-icon>
            </template>
            <v-list-item-title>Abmelden</v-list-item-title>
          </v-list-item>
        </v-list>
      </v-menu>
    </v-app-bar>

    <!-- Main Content -->
    <v-main>
      <router-view />
    </v-main>

    <!-- PWA Update Snackbar -->
    <v-snackbar
      v-model="showUpdateSnackbar"
      :timeout="-1"
      color="primary"
    >
      Eine neue Version ist verfügbar!
      <template v-slot:actions>
        <v-btn
          variant="text"
          @click="updateApp"
        >
          Aktualisieren
        </v-btn>
      </template>
    </v-snackbar>

    <!-- Global Snackbar -->
    <v-snackbar
      v-model="snackbar.show"
      :color="snackbar.color"
      :timeout="snackbar.timeout"
    >
      {{ snackbar.message }}
      <template v-slot:actions>
        <v-btn variant="text" @click="snackbar.show = false">
          Schließen
        </v-btn>
      </template>
    </v-snackbar>
  </v-app>
</template>

<script setup>
import { ref, computed, onMounted, watch, provide } from 'vue'
import { useRouter } from 'vue-router'
import { useTheme } from 'vuetify'
import { useAuthStore } from '@/stores/auth'
import { useSettingsStore } from '@/stores/settings'
import ThemeSwitch from '@/components/ThemeSwitch.vue'
import axios from 'axios'

const router = useRouter()
const theme = useTheme()
const authStore = useAuthStore()
const settingsStore = useSettingsStore()

// State
const drawer = ref(true)
const apiStatus = ref(true)
const showUpdateSnackbar = ref(false)

// Snackbar
const snackbar = ref({
  show: false,
  message: '',
  color: 'success',
  timeout: 3000
})

// Provide snackbar globally
provide('snackbar', snackbar)

// Menu Items
const menuItems = [
  { title: 'Dashboard', path: '/', icon: 'mdi-view-dashboard' },
  { title: 'Analysen', path: '/analysis', icon: 'mdi-chart-bar' },
  { title: 'Samples', path: '/sample', icon: 'mdi-test-tube' },
  { title: 'Boxen', path: '/box', icon: 'mdi-package-variant' },
  { title: 'Log', path: '/log', icon: 'mdi-file-document' }
]

// Current Theme
const currentTheme = computed(() => 
  settingsStore.isDarkMode ? 'dark' : 'light'
)

// Watch theme changes
watch(currentTheme, (newTheme) => {
  theme.global.name.value = newTheme
}, { immediate: true })

// Check API Status
async function checkApiStatus() {
  try {
    await axios.get('/api/box', { timeout: 5000 })
    apiStatus.value = true
  } catch {
    apiStatus.value = false
  }
}

// Logout
function handleLogout() {
  authStore.logout()
  router.push('/login')
}

// PWA Update
function updateApp() {
  showUpdateSnackbar.value = false
  window.location.reload()
}

// Register Service Worker Updates
onMounted(() => {
  // Initial theme
  theme.global.name.value = currentTheme.value

  // Check API status periodically
  checkApiStatus()
  setInterval(checkApiStatus, 30000)

  // PWA Update Detection
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.addEventListener('controllerchange', () => {
      showUpdateSnackbar.value = true
    })
  }
})
</script>

<style>
/* PWA Standalone Modus Anpassungen */
@media all and (display-mode: standalone) {
  .v-app-bar {
    padding-top: env(safe-area-inset-top);
  }
  
  .v-navigation-drawer {
    padding-top: env(safe-area-inset-top);
  }
}

/* Smooth transitions */
.v-main {
  transition: padding 0.2s ease;
}
</style>
