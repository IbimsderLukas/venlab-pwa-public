// main.js
import { createApp } from 'vue'
import { createPinia } from 'pinia'
import App from './App.vue'
import router from './router'
import vuetify from './plugins/vuetify'

// Styles
import './styles/main.scss'

// PWA Service Worker Registration
import { registerSW } from 'virtual:pwa-register'

// Create App
const app = createApp(App)

// Pinia Store
const pinia = createPinia()
app.use(pinia)

// Router
app.use(router)

// Vuetify
app.use(vuetify)

// Mount
app.mount('#app')

// Register Service Worker
const updateSW = registerSW({
  onNeedRefresh() {
    // Show update prompt
    if (confirm('Neue Version verfügbar. Jetzt aktualisieren?')) {
      updateSW()
    }
  },
  onOfflineReady() {
    console.log('App ist offline verfügbar')
  },
  onRegistered(r) {
    console.log('Service Worker registriert')
    // Check for updates every hour
    if (r) {
      setInterval(() => {
        r.update()
      }, 60 * 60 * 1000)
    }
  },
  onRegisterError(error) {
    console.error('SW Registrierung fehlgeschlagen:', error)
  }
})
