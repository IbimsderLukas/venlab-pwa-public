<template>
  <v-menu :close-on-content-click="false" location="bottom">
    <template v-slot:activator="{ props }">
      <v-btn
        v-bind="props"
        variant="outlined"
        size="small"
        prepend-icon="mdi-table-column"
      >
        Spalten
        <v-badge
          :content="selectedCount"
          :color="selectedCount > 0 ? 'primary' : 'grey'"
          inline
          class="ml-2"
        />
      </v-btn>
    </template>

    <v-card min-width="280" max-height="400">
      <v-card-title class="text-subtitle-1 pb-0">
        Spalten auswählen
      </v-card-title>
      
      <v-card-text class="pt-2">
        <v-checkbox
          v-for="column in availableColumns"
          :key="column.key"
          v-model="selectedColumns"
          :label="column.label"
          :value="column.key"
          density="compact"
          hide-details
          class="mb-1"
        />
      </v-card-text>

      <v-divider />

      <v-card-actions>
        <v-btn
          size="small"
          variant="text"
          @click="selectAll"
        >
          Alle
        </v-btn>
        <v-btn
          size="small"
          variant="text"
          @click="selectNone"
        >
          Keine
        </v-btn>
        <v-spacer />
        <v-btn
          size="small"
          variant="text"
          color="primary"
          @click="resetDefaults"
        >
          Standard
        </v-btn>
      </v-card-actions>
    </v-card>
  </v-menu>
</template>

<script setup>
import { computed, watch } from 'vue'
import { useSettingsStore } from '@/stores/settings'

const props = defineProps({
  table: {
    type: String,
    required: true
  }
})

const emit = defineEmits(['update:columns'])

const settingsStore = useSettingsStore()

const availableColumns = computed(() => 
  settingsStore.getAvailableColumns(props.table)
)

const selectedColumns = computed({
  get: () => settingsStore.getColumns(props.table),
  set: (value) => {
    settingsStore.setColumns(props.table, value)
    emit('update:columns', value)
  }
})

const selectedCount = computed(() => selectedColumns.value.length)

function selectAll() {
  selectedColumns.value = availableColumns.value.map(col => col.key)
}

function selectNone() {
  // Mindestens eine Spalte muss ausgewählt sein
  const firstColumn = availableColumns.value[0]?.key
  selectedColumns.value = firstColumn ? [firstColumn] : []
}

function resetDefaults() {
  const defaults = availableColumns.value
    .filter(col => col.default)
    .map(col => col.key)
  selectedColumns.value = defaults
}

// Initial emit
watch(selectedColumns, (newVal) => {
  emit('update:columns', newVal)
}, { immediate: true })
</script>
