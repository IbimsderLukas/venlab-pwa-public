<template>
  <v-btn
    icon
    variant="text"
    @click="toggleTheme"
    :title="isDarkMode ? 'Zu hellem Design wechseln' : 'Zu dunklem Design wechseln'"
  >
    <v-icon>{{ isDarkMode ? 'mdi-weather-sunny' : 'mdi-weather-night' }}</v-icon>
  </v-btn>
</template>

<script setup>
import { computed } from 'vue'
import { useTheme } from 'vuetify'
import { useSettingsStore } from '@/stores/settings'

const theme = useTheme()
const settingsStore = useSettingsStore()

const isDarkMode = computed(() => settingsStore.isDarkMode)

function toggleTheme() {
  settingsStore.toggleTheme()
  theme.global.name.value = settingsStore.isDarkMode ? 'dark' : 'light'
}
</script>
